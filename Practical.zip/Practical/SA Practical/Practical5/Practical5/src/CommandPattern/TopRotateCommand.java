package CommandPattern;

public class TopRotateCommand implements CommandBase{

	RotatingTop rotatingTop;
	public TopRotateCommand(RotatingTop rotatingTop) {
		this.rotatingTop = rotatingTop;
	}
	@Override
	public void execute() {
		System.out.println("TopRotateCommand execute(): Invoking startRotating() on RotatingTop");
		rotatingTop.startRotating();
	}
	@Override
	public void undo() {
		System.out.println("TopRotateCommand undo(): Undoing previous action -> Ivoking stopRotating() on RotatingTop");
		rotatingTop.stopRotating();
	}
	
}
