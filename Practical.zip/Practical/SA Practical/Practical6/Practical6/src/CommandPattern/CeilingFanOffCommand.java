package CommandPattern;

public class CeilingFanOffCommand {

}
