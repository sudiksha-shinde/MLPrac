package Iterator;
import java.util.Iterator;

public class DinnerMenu implements Menu{
	
	static final int MAX_ITEMS = 6;
	int numberOfItems = 0;
	MenuItem[] menuItems;
	
	public void addItem(String name, String description, boolean vegetarian, double price) {
		MenuItem menuItem = new MenuItem(name, description, vegetarian, price);
		if(numberOfItems >= MAX_ITEMS) {
			System.err.println("Sorry, menu is full! Cant add item to menu");
		}
		else {
			menuItems[numberOfItems] = menuItem;
			numberOfItems = numberOfItems + 1;
		}
	}
	public MenuItem[] getMenuItems() {
		return menuItems;
	}
	public DinnerMenu() {
		menuItems = new MenuItem[MAX_ITEMS];
		addItem("Vegetarian BLT","(Fakin') Bacon with lettuce & tomato on whole wheat", true, 2.99);
		addItem("BLT","Bacon with lettuce & tomato on whole wheat", false, 2.99);
		addItem("Soup of the Day!","Soup of the day with a side of potato salad", false, 3.29);
		addItem("Hotdog","Hotdog with saurkraut, relish, onions, topped with cheese", false, 3.05);
		addItem("Steamed veggies & Brown Rice","Steamed vegetables over brown rice", true, 3.99);
		addItem("Pasta","Spagetti with Marinara Sauce and a slice of sourdough bread", true, 3.89);
	}
	public Iterator createIterator() {
		return (Iterator) new DinnerMenuIterator(menuItems);
	}
}
