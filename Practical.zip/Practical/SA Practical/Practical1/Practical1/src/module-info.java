/**
 * 
 */
/**
 * @author Mahreen-PC
 *
 */
module Practical1 {
}