package observer1;

public interface DisplayElement {
	public void display();
}
