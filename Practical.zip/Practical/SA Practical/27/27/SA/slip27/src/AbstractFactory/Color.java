package AbstractFactory;

public interface Color {
	void fill();
}
